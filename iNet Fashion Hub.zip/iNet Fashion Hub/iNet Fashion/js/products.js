var addButton = document.querySelector('#addButton');
var input = document.querySelector('#input');

addButton.addEventListener('click', function() {
  var value = input.value.trim();
  if (value !== '') {
    add(value);
    input.value = '';
  }
});
