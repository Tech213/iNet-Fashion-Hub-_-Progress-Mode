const navSlide = () => {
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.nav-links');
  const navLinks = document.querySelectorAll('.nav-links li')
  
  burger.addEventListener('click',()=> {
      //toggle nav
      nav.classList.toggle('nav-active');

        // animate links
      navLinks.forEach((link, index) => {
          if (link.style.animation){
              link.style.animation = ''
          }
          else{
              link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0.6 }s`;
          }  
      });
      //burger animation
      burger.classList.toggle('toggle');

  });


}


searchForm.addEventListener('submit', function(event) {
event.preventDefault();
const searchTerm = searchInput.value.trim();
if (searchTerm !== '') {
  // Send search query to server and display results
  console.log('Searching for: ' + searchTerm);
}
});


navSlide();


const products = [
  {name: "T-Shirt", category: "Clothing", price: 20},
  {name: "Jeans", category: "Clothing", price: 50},
  {name: "Sneakers", category: "Footwear", price: 80},
  {name: "Watch", category: "Accessories", price: 100},
  {name: "Backpack", category: "Bags", price: 60},
  {name: "Jacket", category: "Clothing", price: 120},
  {name: "Hat", category: "Accessories", price: 25},
  {name: "Sandals", category: "Footwear", price: 40},
  {name: "Purse", category: "Bags", price: 90}
];

function searchProducts(searchText) {
  const filteredProducts = products.filter(function(product) {
    return product.name.toLowerCase().includes(searchText.toLowerCase()) || product.category.toLowerCase().includes(searchText.toLowerCase());
  });
  return filteredProducts;
}

// Example usage:
const searchText = "Clothing";
const filteredProducts = searchProducts(searchText);
console.log(filteredProducts);
// Output: [{name: "T-Shirt", category: "Clothing", price: 20}, {name: "Jeans", category: "Clothing", price: 50}, {name: "Jacket", category: "Clothing", price: 120}]


